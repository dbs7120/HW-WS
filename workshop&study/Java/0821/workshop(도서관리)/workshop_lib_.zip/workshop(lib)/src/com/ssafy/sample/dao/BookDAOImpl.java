package com.ssafy.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.sample.vo.Book;

public class BookDAOImpl implements BookDAO {

	private static final String addSQL = "insert into book values (?, ?, ?, ?, ?, ?)";
	private static final String selectAllSQL = "select * from book";
	private static final String selectIsbnSQL = "select * from book where isbn = ?";
	private static final String updatePriceSQL = "update book set price = ? where isbn = ?";
	private static final String deleteSQL = "delete from book where isbn = ?";

	@Override
	public boolean addBook(Book book) {
		boolean flag = false;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(addSQL);
			pstmt.setString(1, book.getIsbn());
			pstmt.setString(2, book.getTitle());
			pstmt.setString(3, book.getAuthor());
			pstmt.setString(4, book.getPublisher());
			pstmt.setInt(5, book.getPrice());
			if(book.getDescription()==null)
				pstmt.setNull(6, Types.VARCHAR);
			else
				pstmt.setString(6, book.getDescription());
			int cnt = pstmt.executeUpdate();
			if (cnt == 1) {
				flag = true;
			}
			System.out.println("add Success");

		} catch (SQLException e) {
			System.out.println("add e : " + e);

		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return flag;

	}

	@Override
	public List<Book> getListAll() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<Book> books = new ArrayList<Book>();

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(selectAllSQL);
			rs = pstmt.executeQuery();

			Book book = null;
			while (rs.next()) {
				book = new Book();
				book.setIsbn(rs.getString(1));
				book.setTitle(rs.getString(2));
				book.setAuthor(rs.getString(3));
				book.setPublisher(rs.getString(4));
				book.setPrice(rs.getInt(5));
				book.setDescription(rs.getString(6));
				books.add(book);
			}

			System.out.println("select All Success");

		} catch (SQLException e) {
			System.out.println("select all e : " + e);
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}

		return books;
	}

	@Override
	public void selectIsbn(Book book) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(selectIsbnSQL);
			pstmt.setString(1, book.getIsbn());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				// book.setIsbn(rs.getString(1));
				book.setTitle(rs.getString(2));
				book.setAuthor(rs.getString(3));
				book.setPublisher(rs.getString(4));
				book.setPrice(rs.getInt(5));
				book.setDescription(rs.getString(6));
			}

			System.out.println("select ISBN Success");

		} catch (SQLException e) {
			System.out.println("select ISBN e : " + e);
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
	}

	@Override
	public boolean updateBookPrice(String isbn, int price) {
		boolean flag = false;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(updatePriceSQL);
			pstmt.setInt(1, price);
			pstmt.setString(2, isbn);

			int cnt = pstmt.executeUpdate();
			if (cnt == 1) {
				flag = true;
			}
			System.out.println("update Success");

		} catch (SQLException e) {
			System.out.println("update e : " + e);

		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return flag;
	}

	@Override
	public boolean deleteBook(String isbn) {
		boolean flag = false;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(deleteSQL);
			pstmt.setString(1, isbn);

			int cnt = pstmt.executeUpdate();
			if (cnt == 1) {
				flag = true;
			}
			System.out.println("delete Success");

		} catch (SQLException e) {
			System.out.println("delete e : " + e);

		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(con);
		}
		return flag;

	}

}
