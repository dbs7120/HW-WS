package com.ssafy.sample.util;

import java.util.List;

import com.google.gson.Gson;
import com.ssafy.sample.service.BookService;
import com.ssafy.sample.service.BookServiceImpl;
import com.ssafy.sample.vo.Book;
import com.ssafy.sample.vo.BookListResult;

// single ton
public class BookManager {

	private static BookManager instance;

	BookService service = new BookServiceImpl();

	private BookManager() {

	}

	public static BookManager getInstance() {
		if (instance == null) {
			instance = new BookManager();
		}
		return instance;
	}

	public boolean addBook(Book book) {
		return service.addBook(book);
	}

	public List<Book> getListAll() {
		return service.getListAll();
	}

	public void selectIsbn(Book book) {
		service.selectIsbn(book);

	}

	public String getListToJson() {
		List<Book> list = service.getListAll();
		BookListResult result = new BookListResult();
		
		result.setList(list);
		result.setSize(list.size());
		result.setStatus("success");
		Gson gson = new Gson();
		
		return gson.toJson(result);
	}

	public boolean updateBookPrice(String isbn, int price) {
		return service.updateBookPrice(isbn, price);
	}

	public boolean deleteBook(String isbn) {
		return service.deleteBook(isbn);
	}

}
