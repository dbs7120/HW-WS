package com.ssafy.sample.dao;

import java.util.List;

import com.ssafy.sample.vo.Book;

public interface BookDAO {
	boolean addBook(Book book);
	List<Book> getListAll();
	void selectIsbn(Book book);
	boolean updateBookPrice(String isbn, int price);
	boolean deleteBook(String isbn);
}
