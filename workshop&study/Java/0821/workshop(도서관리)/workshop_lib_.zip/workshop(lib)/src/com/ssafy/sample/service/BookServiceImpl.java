package com.ssafy.sample.service;

import java.util.List;

import com.ssafy.sample.dao.BookDAO;
import com.ssafy.sample.dao.BookDAOImpl;
import com.ssafy.sample.vo.Book;

public class BookServiceImpl implements BookService {
	BookDAO dao = new BookDAOImpl();

	@Override
	public boolean addBook(Book book) {
		return dao.addBook(book);
	}

	@Override
	public List<Book> getListAll() {
		return dao.getListAll();
	}

	@Override
	public void selectIsbn(Book book) {
		dao.selectIsbn(book);
		
	}

	@Override
	public boolean updateBookPrice(String isbn, int price) {
		return dao.updateBookPrice(isbn, price);
	}

	@Override
	public boolean deleteBook(String isbn) {
		return dao.deleteBook(isbn);
	}

}
