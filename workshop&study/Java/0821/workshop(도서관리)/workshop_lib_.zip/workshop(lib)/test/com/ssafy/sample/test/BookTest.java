package com.ssafy.sample.test;

import java.util.List;
import java.util.Scanner;

// client(WEB,Consol,...) - manager - service - dao - DB(MySQL) => 확장성
import com.ssafy.sample.util.BookManager;
import com.ssafy.sample.vo.Book;

public class BookTest {
	public BookTest() {

		BookManager manager = BookManager.getInstance();
		Scanner sc = new Scanner(System.in);
		Book book = null;
		boolean check = false;

		String isbn = "12345678";
		String title = "싸피 BOOK";
		String author = "김SSAFY";
		String publisher = "S전자";
		int price = 10000;
		String description = "IT 개발 교재";

		while (true) {

			System.out.println("┌─────────────────────Book manager Program──────────────────────┐");
			System.out.println("│\t\t\t1. 도서 추가\t\t\t\t│");
			System.out.println("│\t\t\t2. 현재 도서 목록\t\t\t\t│");
			System.out.println("│\t\t\t3. 도서 목록 검색(ISBN)\t\t\t│");
			System.out.println("│\t\t\t4. 가격 수정\t\t\t\t│");
			System.out.println("│\t\t\t5. 도서 삭제\t\t\t\t│");
			System.out.println("│\t\t\t6. JSON목록으로 검색\t\t\t\t│");
			System.out.println("│\t\t\t0. 프로그램 종료\t\t\t\t│");
			System.out.println("└───────────────────────────────────────────────────────────────┘");

			int menu;
			menu = Integer.parseInt(sc.nextLine());

			switch (menu) {

			case 1: // insert
				book = new Book();
				System.out.println(">도서 추가\n");
				System.out.print(">ISBN:");
				isbn = sc.nextLine();
				System.out.print(">제목:");
				title = sc.nextLine();
				System.out.print(">저자:");
				author = sc.nextLine();
				System.out.print(">출판사:");
				publisher = sc.nextLine();
				System.out.print(">가격:");
				price = Integer.parseInt(sc.nextLine());
				System.out.print(">설명");
				description = sc.nextLine();

				book.setIsbn(isbn);
				book.setTitle(title);
				book.setAuthor(author);
				book.setPublisher(publisher);
				book.setPrice(price);

				if (description.equals("")) {
					book.setDescription(null);
				} else
					book.setDescription(description);
				System.out.println(description);

				check = manager.addBook(book);
				System.out.println(check ? ">추가완료" : ">추가실패");
				System.out.println();
				break;

			case 2: // select *
				System.out.println(">전체 도서 목록\n");
				List<Book> list = manager.getListAll();
				if (list.size() == 0) {
					System.out.println("항목이 비어있습니다.");
				} else {
					for (Book b : list) {
						System.out.println(b);
					}
				}
				System.out.println();

				break;

			case 3: // select by isbn
				System.out.println(">도서 목록 검색(ISBN)\n");
				System.out.print("ISBN:");

				isbn = sc.nextLine();

				// Object 전달 방식
				book = new Book();
				book.setIsbn(isbn);
				manager.selectIsbn(book);
				if (book.getTitle() == null) {
					System.out.println("없는 도서");
				} else {
					System.out.println(book);
				}
				System.out.println();
				break;

			case 4: // Update
				System.out.println(">가격 수정\n");
				System.out.print(">ISBN:");
				isbn = sc.nextLine();
				System.out.print(">가격:");
				price = Integer.parseInt(sc.nextLine());
				check = manager.updateBookPrice(isbn, price);
				System.out.println(check ? ">변경완료" : ">변경실패");
				System.out.println();
				break;

			case 5: // Delete
				System.out.println(">도서 삭제\n");
				System.out.print(">ISBN:");
				isbn = sc.nextLine();
				check = manager.deleteBook(isbn);
				System.out.println(check ? ">삭제완료" : ">삭제실패");
				System.out.println();

				break;

			case 6:
				System.out.println(">JSON 형식으로 출력\n");
				String json = manager.getListToJson();
				System.out.println(json);
				break;

			case 0:
				break;

			}
			if (menu == 0)
				break;

		}
		sc.close();

	}

	public static void main(String[] args) {
		new BookTest();
	}

}
