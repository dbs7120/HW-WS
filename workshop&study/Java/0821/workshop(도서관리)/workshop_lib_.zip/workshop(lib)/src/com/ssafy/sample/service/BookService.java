
package com.ssafy.sample.service;

import java.util.List;

import com.ssafy.sample.vo.Book;

public interface BookService {
	boolean addBook(Book book);

	List<Book> getListAll();

	void selectIsbn(Book book);

	boolean updateBookPrice(String isbn, int price);

	boolean deleteBook(String isbn);


}
